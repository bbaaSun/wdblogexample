WINDGROOVE WEEK 1 — CMS CONTENT

Use p001.html through p007.html as article-body HTML, not the standalone review pages in week1/.
Each title belongs in the CMS title field. metadata.json supplies the title, description and planned URL for each article.
Add article.css to the theme once. Its rules are scoped to .wd-blog and include narrow-screen tables.
Upload the four images and the airflow worksheet from assets/ to the brand CMS. Replace the assets/... references with the URLs returned by that upload. Preserve the supplied image alt text.
Cross-article links already use the planned WindGroove URLs from metadata.json. Publish the seven destinations together, or adjust those URLs if the CMS slugs differ.
Review-site navigation and noindex metadata are excluded from these body files. The brand theme supplies its own page layout and indexing settings.
The folder week1/ contains the matching full-page review and editable text copies.
